from textwrap import dedent
from typing import Union


def lambdex(args: Union[tuple, str, dict], code: str):
    """

    Args:
        args: (str, ..., optional dict)|str|dict.
            e.g. ('x')
                 ('x', 'y')
                 ('x', 'y', {'factor': 1000})
                 ({'factor': 1000})
        code: long str. you can start with indent, we'll deindent it then.

    Usages:
        See `https://github.com/likianta/lambdex/examples`
    """
    # extract `args_`, `globals_` from `args`
    if args:
        if isinstance(args, str):
            args_, globals_ = args, {}
        elif isinstance(args, dict):
            args_, globals_ = '', args
        # then assert isinstance(args, tuple)
        elif isinstance(args[-1], dict):
            args_, globals_ = ', '.join(args[:-1]), args[-1]
        else:
            args_, globals_ = ', '.join(args), {}
    else:
        args_, globals_ = '', {}
    
    # compose `code_` from `code`
    # note: `somefunc` is the function name of `code`, we need to add a wrapper
    # for `somefunc`, to make sure `somefunc` accepts recursive calls. see
    # reasons at <https://stackoverflow.com/questions/871887/using-exec-with
    # -recursive-functions> and some tests at <https://github.com/likianta
    # /lambdex/examples/03_fibonacci.py>
    code_ = dedent('''
        def LAMBDEX_FUNC_WRAPPER({args}):
            def somefunc({args}):
                {body}
            return somefunc({args})
        LAMBDEX_RESULT = LAMBDEX_FUNC_WRAPPER
    ''').format(
        args=args_,
        body='\n        '.join(dedent(code).split('\n'))
        #       ^------^ 8 whitespaces, follows the indent of '{body}'
    )
    somefunc = _exec(code_, globals_, ret="LAMBDEX_RESULT")
    # print(code_, somefunc)
    
    return eval(f'lambda {args_}: somefunc({args_})', {'somefunc': somefunc})


def _exec(code: str, globals_=None, locals_=None, ret='RESULT'):
    """
    Args:
        code
        globals_ (dict)
        locals_ (dict)
        ret
    
    Usages:
        # == 1. no args ==
        a = _exec('''
            x = 1
            y = 2
            RESULT = x + y
        ''')
        print(a())  # -> 3

        # == 2. with args ==
        b = lambda x, y: _exec('''
            RESULT = x + y
        ''', {'x': x, 'y': y})
        print(b(1, 2))  # -> 3

    References:
        https://stackoverflow.com/questions/1463306/how-does-exec-work-with
        -locals
    """
    if globals_ is None: globals_ = {}
    if locals_ is None: locals_ = {}
    exec(code, globals_, locals_)
    return locals_[ret]
