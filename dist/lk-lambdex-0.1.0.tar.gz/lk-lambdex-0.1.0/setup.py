# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['lk_lambdex']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'lk-lambdex',
    'version': '0.1.0',
    'description': 'A simple way to compose multi-line anonymous function in Python.',
    'long_description': None,
    'author': 'Likianta',
    'author_email': 'likianta@foxmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.0,<4.0',
}


setup(**setup_kwargs)
